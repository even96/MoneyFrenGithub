package edu.bluejack15_2.moneyfren;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Map;

public class LoginActivity extends AppCompatActivity implements ValueEventListener, View.OnClickListener{

    private Firebase mRef;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Firebase.setAndroidContext(this);
    }

    @Override
    protected void onStart() {
        super.onStart();

        mRef = new Firebase("https://moneyfren-ee0bd.firebaseio.com/ListData");

        Firebase data = mRef.child("UserData");
        data.addValueEventListener(this);

        loginButton.setOnClickListener(this);
    }

    @Override
    public void onDataChange(DataSnapshot dataSnapshot) {
        //Map<String, String> map = dataSnapshot.getValue(Map.class);
        //String password = map.get("Password");
        //String username = map.get("Username");

        //Log.v("testing", username + " " +password);

        //String test = (String) dataSnapshot.getValue();
        //Log.v("testing",test);
    }

    @Override
    public void onCancelled(FirebaseError firebaseError) {

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.login_btnLogin)
        {
            
        }
    }
}
