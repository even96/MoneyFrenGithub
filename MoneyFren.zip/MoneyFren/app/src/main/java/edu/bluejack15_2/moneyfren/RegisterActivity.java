package edu.bluejack15_2.moneyfren;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.firebase.client.Firebase;

import org.w3c.dom.Text;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    Firebase mRef;

    Button btnRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Firebase.setAndroidContext(this);
    }

    @Override
    protected void onStart() {
        super.onStart();
        btnRegis = (Button) findViewById(R.id.register_btnRegister);
        btnRegis.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.register_btnRegister)
        {
            EditText et_username = (EditText) findViewById(R.id.register_txtUsername);
            EditText et_password = (EditText) findViewById(R.id.register_txtPassword);
            EditText et_confirmPassword = (EditText) findViewById(R.id.register_txtConfirmPassword);
            EditText et_telephone = (EditText) findViewById(R.id.register_txtTelephone);

            TextView txtAlert = (TextView) findViewById(R.id.register_txtAlert);

            String username = et_username.getText().toString();
            String password = et_password.getText().toString();
            String confirm_password = et_confirmPassword.getText().toString();
            String telephone = et_telephone.getText().toString();

            if(username.equals(""))
            {
                txtAlert.setText("Username cannot be empty");
            }
            else if(password.equals(""))
            {
                txtAlert.setText("Password cannot be empty");
            }
            else if(confirm_password.equals(""))
            {
                txtAlert.setText("Confirm password cannot be empty");
            }
            else if(!confirm_password.equals(password))
            {
                txtAlert.setText("Password & Confirm password does not match");
            }
            else if(telephone.equals(""))
            {
                txtAlert.setText("Telephone cannot be empty");
            }
            else
            {
                UserModel userModel = new UserModel(username,password,telephone);

                Firebase mRef = new Firebase("https://moneyfren-ee0bd.firebaseio.com/ListData");
                Firebase userRef = mRef.child(username);

                userRef.setValue(userModel);

                txtAlert.setText("OK");
                //tinggal pindah halaman.. ini udah ke save
            }

            //Log.v("cek text",username+password+confirm_password+telephone);
        }
    }
}
